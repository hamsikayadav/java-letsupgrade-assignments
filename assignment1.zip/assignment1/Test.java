
public class Test{
public static void main(String[] args){

  Employee emp1=new Employee();
  emp1.display("Saurab", 23, "Chennai");

  Employee emp2=new Employee();
  emp2.display("Sameul", 24, "Hyderabad");
}
}
