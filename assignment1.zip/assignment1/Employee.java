public class Employee
{
  String name;
  int age;
  String city;
  public void display(String name, int age, String city){
      this.name=name;
      this.age=age;
      this.city=city;

   System.out.println("The name is " + name + "The age is " + age + "The city is " + city);
 }
}
